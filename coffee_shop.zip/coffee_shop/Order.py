from Menu import menu

orders = []


def add_order():
    name = input("نام محصول: ").strip().lower()
    if name not in menu:
        print("این محصول در منو وجود ندارد.")
        return
    quantity = input("تعداد: ").strip()
    if not quantity.isdigit() or int(quantity) <= 0:
        print("تعداد واردشده معتبر نیست.")
        return
    orders.append({
        "name": name,
        "price": menu[name],
        "quantity": int(quantity)
    })
    print("سفارش ثبت شد.")


def show_orders():
    if not orders:
        print("هنوز سفارشی ثبت نشده است.")
        return
    for order in orders:
        print(f"محصول: {order['name']} | قیمت: {order['price']} | تعداد: {order['quantity']}")
