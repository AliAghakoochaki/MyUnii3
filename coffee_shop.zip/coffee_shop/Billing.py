from Order import orders


def calculate_total():
    total = 0
    for order in orders:
        total += order["price"] * order["quantity"]
    return total


def calculate_discount(total):
    if total > 1000000:
        return total * 10 / 100
    return 0


def print_invoice():
    if not orders:
        print("هنوز سفارشی ثبت نشده است.")
        return
    total = calculate_total()
    discount = calculate_discount(total)
    final_amount = total - discount
    print("========== فاکتور ==========")
    for order in orders:
        print(f"{order['name']} × {order['quantity']}")
    print(f"مبلغ کل: {total}")
    print(f"تخفیف: {discount}")
    print(f"مبلغ نهایی قابل پرداخت: {final_amount}")
